import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const windows = pgTable("windows", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  x: integer("x").notNull(),
  y: integer("y").notNull(),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  isMinimized: boolean("is_minimized").notNull().default(false),
  isMaximized: boolean("is_maximized").notNull().default(false),
  displayId: integer("display_id").notNull(),
  content: jsonb("content").notNull()
});

export const displays = pgTable("displays", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  isActive: boolean("is_active").notNull().default(true)
});

export const windowInsertSchema = createInsertSchema(windows);
export const displayInsertSchema = createInsertSchema(displays);

export type Window = typeof windows.$inferSelect;
export type InsertWindow = z.infer<typeof windowInsertSchema>;
export type Display = typeof displays.$inferSelect;
export type InsertDisplay = z.infer<typeof displayInsertSchema>;
