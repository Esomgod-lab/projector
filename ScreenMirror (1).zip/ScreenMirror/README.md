# Remote Display Control Application

A web-based remote display control application that allows users to view and control content from an extended monitor directly on their primary screen.

## Features
- Mirror/capture extended screen display in real-time
- Window management and manipulation
- Maximize/minimize windows
- Drag and drop interface

## Setup Instructions

### Prerequisites
- Node.js 20.x or later
- npm 9.x or later

### Local Development

1. Clone the repository:
```bash
git clone <your-repo-url>
cd remote-display-control
```

2. Install dependencies:
```bash
npm install
```

3. Start development server:
```bash
npm run dev
```
The app will be available at `http://localhost:5000`

### Production Build

1. Build the application:
```bash
npm run build
```

2. Start production server:
```bash
npm start
```

## Environment Variables
Create a `.env` file in the root directory with the following variables:

```env
PORT=5000 # Server port (optional, defaults to 5000)
NODE_ENV=development # or production
```

## Deployment

### Static Export
To deploy as a static site:

1. Build the project:
```bash
npm run build
```

2. The built files will be in the `dist/public` directory
3. Deploy the contents of `dist/public` to any static hosting service

### Server Deployment
For full functionality including API:

1. Build the project:
```bash
npm run build
```

2. Deploy the entire `dist` directory
3. Run `npm start` on your server

## Architecture
- Frontend: React + Vite
- Backend: Express
- State Management: TanStack Query
- UI Components: shadcn/ui
- Styling: Tailwind CSS

## Project Structure
```
├── client/           # Frontend React application
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   └── lib/
├── server/           # Backend Express server
├── shared/           # Shared types and utilities
└── dist/            # Built application
    ├── public/      # Static assets
    └── server/      # Compiled server