import { Window } from "@shared/schema";

export function isWindowVisible(window: Window): boolean {
  return !window.isMinimized;
}

export function getWindowBounds(window: Window) {
  return {
    left: window.x,
    top: window.y,
    right: window.x + window.width,
    bottom: window.y + window.height
  };
}

export function isPointInWindow(x: number, y: number, window: Window): boolean {
  const bounds = getWindowBounds(window);
  return x >= bounds.left && x <= bounds.right && y >= bounds.top && y <= bounds.bottom;
}
