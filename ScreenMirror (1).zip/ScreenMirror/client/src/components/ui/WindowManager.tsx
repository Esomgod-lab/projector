import { Window } from "@shared/schema";
import { DisplayWindow } from "../display/DisplayWindow";
import { useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface WindowManagerProps {
  windows: Window[];
  onWindowMove: (id: number, x: number, y: number) => void;
}

export function WindowManager({ windows, onWindowMove }: WindowManagerProps) {
  const queryClient = useQueryClient();

  const updateWindowMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Window> }) => {
      await apiRequest("PATCH", `/api/windows/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/displays/1/windows'] });
    }
  });

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const windowId = parseInt(e.dataTransfer.getData("text/plain"));
    if (!isNaN(windowId)) {
      const bounds = e.currentTarget.getBoundingClientRect();
      const x = e.clientX - bounds.left;
      const y = e.clientY - bounds.top;
      onWindowMove(windowId, x, y);
    }
  }, [onWindowMove]);

  const handleMaximizeDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const windowId = parseInt(e.dataTransfer.getData("text/plain"));
    if (!isNaN(windowId)) {
      updateWindowMutation.mutate({
        id: windowId,
        updates: {
          isMaximized: true,
          isMinimized: false,
          x: 0,
          y: 0,
          width: 1920,
          height: 1080
        }
      });
    }
  }, [updateWindowMutation]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  return (
    <div className="relative w-full h-full">
      <div 
        className="absolute left-1/2 -translate-x-1/2 top-0 w-32 h-1 bg-transparent hover:bg-primary/20 group transition-all duration-200 before:content-[''] before:absolute before:top-0 before:left-0 before:w-full before:h-4 before:bg-primary/20"
        onDrop={handleMaximizeDrop}
        onDragOver={(e) => {
          e.preventDefault();
          e.currentTarget.classList.add('bg-primary/20');
        }}
        onDragLeave={(e) => {
          e.currentTarget.classList.remove('bg-primary/20');
        }}
      />

      <div 
        className="w-full h-full bg-background border rounded-lg"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        {windows.map(window => (
          <DisplayWindow 
            key={window.id}
            window={window}
            onMove={onWindowMove}
          />
        ))}
      </div>
    </div>
  );
}