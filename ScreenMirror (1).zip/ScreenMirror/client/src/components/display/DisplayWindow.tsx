import { Window } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Maximize2, Minimize2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface DisplayWindowProps {
  window: Window;
  onMove: (id: number, x: number, y: number) => void;
}

export function DisplayWindow({ window, onMove }: DisplayWindowProps) {
  const queryClient = useQueryClient();
  const updateMutation = useMutation({
    mutationFn: async (updates: Partial<Window>) => {
      await apiRequest("PATCH", `/api/windows/${window.id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/displays/${window.displayId}/windows`] });
    }
  });

  const handleDragStart = useCallback((e: React.DragEvent) => {
    e.dataTransfer.setData("text/plain", window.id.toString());
  }, [window.id]);

  const handleMaximize = useCallback(() => {
    updateMutation.mutate({ 
      isMaximized: !window.isMaximized,
      isMinimized: false,
      ...(window.isMaximized ? {
        x: window.x,
        y: window.y,
        width: 800,
        height: 600,
      } : {
        x: 0,
        y: 0,
        width: window.displayId ? 1920 : 800,
        height: window.displayId ? 1080 : 600,
      })
    });
  }, [window, updateMutation]);

  const handleMinimize = useCallback(() => {
    updateMutation.mutate({ isMinimized: !window.isMinimized });
  }, [window.isMinimized, updateMutation]);

  const style = {
    position: "absolute" as const,
    left: window.x,
    top: window.y,
    width: window.width,
    height: window.height,
    transform: window.isMinimized ? "scale(0.8)" : undefined,
    zIndex: window.isMaximized ? 50 : 1,
  };

  return (
    <Card
      draggable={!window.isMaximized}
      onDragStart={handleDragStart}
      className={cn(
        "cursor-move select-none",
        window.isMinimized && "opacity-70",
        window.isMaximized && "cursor-default"
      )}
      style={style}
    >
      <div className="p-2 bg-secondary text-secondary-foreground flex items-center justify-between">
        <span>{window.title}</span>
        <div className="flex gap-2">
          <Button 
            variant="ghost" 
            size="icon"
            className="h-6 w-6"
            onClick={handleMinimize}
          >
            <Minimize2 className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            className="h-6 w-6"
            onClick={handleMaximize}
          >
            <Maximize2 className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <div className="p-4">
        {JSON.stringify(window.content)}
      </div>
    </Card>
  );
}