import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Settings2 } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";

export function DisplaySettings() {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon">
          <Settings2 className="h-4 w-4" />
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Display Settings</SheetTitle>
        </SheetHeader>
        
        <div className="py-6 space-y-6">
          <div className="flex items-center justify-between">
            <Label htmlFor="show-cursor">Show Remote Cursor</Label>
            <Switch id="show-cursor" defaultChecked />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <Label htmlFor="keyboard-input">Enable Keyboard Input</Label>
            <Switch id="keyboard-input" defaultChecked />
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <Label htmlFor="auto-refresh">Auto Refresh (60 FPS)</Label>
            <Switch id="auto-refresh" defaultChecked />
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
