import { Button } from "@/components/ui/button";
import { Display } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { SeparatorHorizontal, MonitorUp, Minimize2, Maximize2 } from "lucide-react";

interface ControlPanelProps {
  display: Display;
  onToggleMinimize: () => void;
  onToggleMaximize: () => void;
}

export function ControlPanel({ display, onToggleMinimize, onToggleMaximize }: ControlPanelProps) {
  return (
    <Card className="w-full">
      <CardContent className="p-4 flex items-center gap-4">
        <div className="flex-1">
          <h3 className="text-lg font-medium">{display.name}</h3>
          <p className="text-sm text-muted-foreground">
            {display.width}x{display.height}
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="icon"
            onClick={onToggleMinimize}
          >
            <Minimize2 className="h-4 w-4" />
          </Button>
          
          <Button 
            variant="outline" 
            size="icon"
            onClick={onToggleMaximize}
          >
            <Maximize2 className="h-4 w-4" />
          </Button>

          <SeparatorHorizontal className="h-6" />
          
          <Button variant="secondary" size="icon">
            <MonitorUp className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
