import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ControlPanel } from "@/components/display/ControlPanel";
import { DisplaySettings } from "@/components/display/DisplaySettings";
import { WindowManager } from "@/components/ui/WindowManager";
import { Display, Window } from "@shared/schema";
import { useCallback } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: display, isLoading: isLoadingDisplay } = useQuery<Display>({
    queryKey: ["/api/displays/active"],
  });

  const { data: windows = [], isLoading: isLoadingWindows } = useQuery<Window[]>({
    queryKey: ["/api/displays/1/windows"],
    enabled: !!display,
  });

  const updateWindowMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Window> }) => {
      await apiRequest("PATCH", `/api/windows/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/displays/${display?.id}/windows`] });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message
      });
    }
  });

  const handleWindowMove = useCallback((id: number, x: number, y: number) => {
    updateWindowMutation.mutate({ id, updates: { x, y } });
  }, [updateWindowMutation]);

  const handleToggleMinimize = useCallback(() => {
    windows.forEach(window => {
      updateWindowMutation.mutate({
        id: window.id,
        updates: { isMinimized: !window.isMinimized }
      });
    });
  }, [windows, updateWindowMutation]);

  const handleToggleMaximize = useCallback(() => {
    windows.forEach(window => {
      updateWindowMutation.mutate({
        id: window.id,
        updates: { isMaximized: !window.isMaximized }
      });
    });
  }, [windows, updateWindowMutation]);

  if (isLoadingDisplay || isLoadingWindows) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-lg text-muted-foreground">Loading display...</p>
      </div>
    );
  }

  if (!display) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-lg text-muted-foreground">No active display found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center gap-4">
          <ControlPanel 
            display={display}
            onToggleMinimize={handleToggleMinimize}
            onToggleMaximize={handleToggleMaximize}
          />
          <DisplaySettings />
        </div>

        <div className="aspect-video">
          <WindowManager 
            windows={windows}
            onWindowMove={handleWindowMove}
          />
        </div>
      </div>
    </div>
  );
}