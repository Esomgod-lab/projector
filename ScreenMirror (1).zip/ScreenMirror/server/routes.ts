import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Get all displays
  app.get("/api/displays", async (_req, res) => {
    const displays = await storage.getAllDisplays();
    res.json(displays);
  });

  // Get active display
  app.get("/api/displays/active", async (_req, res) => {
    const display = await storage.getActiveDisplay();
    if (!display) {
      res.status(404).json({ message: "No active display found" });
      return;
    }
    res.json(display);
  });

  // Get windows for a display
  app.get("/api/displays/:id/windows", async (req, res) => {
    const displayId = parseInt(req.params.id);
    if (isNaN(displayId)) {
      res.status(400).json({ message: "Invalid display ID" });
      return;
    }
    const windows = await storage.getWindowsByDisplay(displayId);
    res.json(windows);
  });

  // Update window position
  app.patch("/api/windows/:id", async (req, res) => {
    const windowId = parseInt(req.params.id);
    if (isNaN(windowId)) {
      res.status(400).json({ message: "Invalid window ID" });
      return;
    }
    const window = await storage.updateWindow(windowId, req.body);
    res.json(window);
  });

  return httpServer;
}
