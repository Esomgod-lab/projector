import { Display, Window } from "@shared/schema";

export interface IStorage {
  // Display operations
  getAllDisplays(): Promise<Display[]>;
  getActiveDisplay(): Promise<Display | undefined>;
  setActiveDisplay(id: number): Promise<Display | undefined>;

  // Window operations
  getWindowsByDisplay(displayId: number): Promise<Window[]>;
  updateWindow(id: number, updates: Partial<Window>): Promise<Window>;
}

export class MemStorage implements IStorage {
  private displays: Map<number, Display>;
  private windows: Map<number, Window>;
  private displayIdCounter: number;
  private windowIdCounter: number;

  constructor() {
    this.displays = new Map();
    this.windows = new Map();
    this.displayIdCounter = 1;
    this.windowIdCounter = 1;

    // Add mock data
    const display1: Display = {
      id: this.displayIdCounter++,
      name: "Extended Display 1",
      width: 1920,
      height: 1080,
      isActive: true
    };
    this.displays.set(display1.id, display1);

    const window1: Window = {
      id: this.windowIdCounter++,
      title: "Sample Window 1",
      x: 100,
      y: 100,
      width: 800,
      height: 600,
      isMinimized: false,
      isMaximized: false,
      displayId: display1.id,
      content: { type: "text", value: "Sample content" }
    };
    this.windows.set(window1.id, window1);
  }

  async getAllDisplays(): Promise<Display[]> {
    return Array.from(this.displays.values());
  }

  async getActiveDisplay(): Promise<Display | undefined> {
    return Array.from(this.displays.values()).find(display => display.isActive);
  }

  async setActiveDisplay(id: number): Promise<Display | undefined> {
    const display = this.displays.get(id);
    if (!display) return undefined;

    // Set all displays to inactive except the selected one
    for (const [, d] of this.displays) {
      d.isActive = d.id === id;
    }

    return display;
  }

  async getWindowsByDisplay(displayId: number): Promise<Window[]> {
    return Array.from(this.windows.values())
      .filter(window => window.displayId === displayId);
  }

  async updateWindow(id: number, updates: Partial<Window>): Promise<Window> {
    const window = this.windows.get(id);
    if (!window) {
      throw new Error(`Window with id ${id} not found`);
    }

    const updatedWindow = { ...window, ...updates };
    this.windows.set(id, updatedWindow);
    return updatedWindow;
  }
}

export const storage = new MemStorage();